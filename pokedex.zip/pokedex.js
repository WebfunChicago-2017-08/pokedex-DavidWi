$(document).ready(function(){
    for(i = 0; i <=151; i ++){  
        $("#pokemon").append("<img src='http://pokeapi.co/media/img/" + i +
        ".png'>");          
    }
});


